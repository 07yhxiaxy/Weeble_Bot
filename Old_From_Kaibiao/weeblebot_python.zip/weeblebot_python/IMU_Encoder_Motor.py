"""
title:lab 1 - ME 439 Intro to robotics
"""

# =================================
#GOALS: Get the motors turning and following closed-loop velocity control patterns
# =================================


#------------imports----------------
import serial
from pololu_drv8835_rpi import motors, MAX_SPEED      # MAX_SPEED is 480 (hard-coded)
import time
import numpy as np
import traceback 
import smbus
import math
import matplotlib
import matplotlib.pyplot as plt
from MPU6050_Comp_Filter import MPU

## Motor Demo
#for spd in range(0,481,1):
#    motors.motor1.setSpeed(spd)
#    time.sleep(0.01)
#    
#for spd in range(480,-481,-1):
#    motors.motor1.setSpeed(spd)
#    time.sleep(0.01)
#    
#for spd in range(-480,1,1): # stops before it gets to 1/100
#    motors.motor1.setSpeed(spd)
#    time.sleep(0.01)
#    
#print( 'Final Speed: {0}'.format(spd) )
#


############# Code for IMU
# Device Address
# This is the address value read via the i2cdetect command. 
# Will be 0x68 (default) or 0x69 (if AD0 is connected to "high"). 
address = 0x68       

# Power management registers
power_mgmt_1 = 0x6b
power_mgmt_2 = 0x6c
 
def read_byte(adr):
    return bus.read_byte_data(address, adr)
 

def read_word(adr):
    high = bus.read_byte_data(address, adr)
    low = bus.read_byte_data(address, adr+1)
    val = (high << 8) + low
    return val
 
def read_word_2c(adr):
    val = read_word(adr)
    if (val >= 0x8000):
        return -((65535 - val) + 1)
    else:
        return val
 
def dist(a,b):
    return math.sqrt((a*a)+(b*b))
 
def get_y_rotation(x,y,z):
    radians = math.atan2(x, dist(y,z))
    return -math.degrees(radians)
 
def get_x_rotation(x,y,z):
    radians = math.atan2(y, dist(x,z))
    return math.degrees(radians)
    
# Access the I2C bus
bus = smbus.SMBus(1) # or bus = smbus.SMBus(1) for Revision 2 boards

# Now wake the 6050 up as it starts in sleep mode
bus.write_byte_data(address, power_mgmt_1, 0)

def read_imu():
    gyro_x = read_word_2c(0x43) / 131
    gyro_y = read_word_2c(0x45) / 131
    gyro_z = read_word_2c(0x47) / 131   

    accel_x = read_word_2c(0x3b) / 16384.0
    accel_y = read_word_2c(0x3d) / 16384.0
    accel_z = read_word_2c(0x3f) / 16384.0
        
    x_rotation = get_x_rotation(accel_x, accel_y, accel_z)
    y_rotation = get_y_rotation(accel_x, accel_y, accel_z)
    # print('gyro_x, gyro_y, gyro_z, accel_x, accel_y, accel_z, x rotation, y rotation: ', gyro_x, gyro_y, gyro_z, accel_x, accel_y, accel_z, x_rotation, y_rotation)
    return (gyro_x, gyro_y, gyro_z, accel_x, accel_y, accel_z, x_rotation, y_rotation)

#########################################################

#----------setup serial port to receive data from AlaMode--------------
ser = serial.Serial('/dev/ttyUSB0')  #serial port to alamode
ser.baudrate = 115200 
ser.bytesize = 8
ser.parity = 'N'
ser.stopbits = 1
ser.timeout = 1 # one second time out. 

# ser.open() causes error if run in Python3 - serial.Serial opened the port already in Python3.
if not ser.is_open: # check if it's not open (should be not open if running Python2)
    ser.open()  # necessary in Python2


# =============================================================================
# # Global Variables
# =============================================================================
# controller variables (used to compute error, error integral, etc.)
# Speed PID
controller_error = 0.0
controller_error_previous = 0.0
controller_error_integral = 0.0
controller_error_derivative = 0.0
controller_error1 = 0.0
controller_error_previous1 = 0.0
controller_error_integral1 = 0.0
controller_error_derivative1 = 0.0
#AngleSpeed PID left
speed_error0 = 0.0
speed_error_previous0 = 0.0
speed_error_integral0 = 0.0
speed_error_derivative0 = 0.0
angle_error0 = 0.0
angle_error_previous0 = 0.0
angle_error_integral0 = 0.0
angle_error_derivative0 = 0.0
#AngleSpeed PID right
speed_error1 = 0.0
speed_error_previous1 = 0.0
speed_error_integral1 = 0.0
speed_error_derivative1 = 0.0
angle_error1 = 0.0
angle_error_previous1 = 0.0
angle_error_integral1 = 0.0
angle_error_derivative1 = 0.0

# =============================================================================
# # EDIT the Drive Train functions to make them represent the real motion of the robot.
# =============================================================================
#---------drive train---------------

def encoder_counts_to_output_shaft_radians(counts, sign):
    # GOAL: accept an input value in Encoder Counts and the sign of the motion...
    # and use the motor's parameters to return an angle in Radians
    angle_output_shaft_rad = counts*sign/12./120.*2*np.pi
    return angle_output_shaft_rad


def calculate_angvel(radPast, radPresent, dt = .01):
    # GOAL: accept inputs of past angle (radians), present angle (radians) ...
    # ... and elapsed time between them dt (here default value is 0.01 but can be overridden...
    # ... and return angular velocity in radians per second
    angvel_output_shaft_radpersec = (radPresent-radPast)/dt
#    print(angvel_output_shaft_radpersec)
    return angvel_output_shaft_radpersec



#---------PID functions-------------


def pidControl0(target, actual, dt):
    """
    takes a target value and an actual value, and dt, and computes PID controller output
    """
# =============================================================================
#     # MANIPULATE these constants to tune controller
# =============================================================================
    #Kp = 20.
    #Ki = 8.
    #Kd = 0.2
    Kp = 50.
    Ki = 20.
    Kd = 0.2

    # We are using Global variables just so they stay in memory. 
    # Here the word "global" gives this function (pidControl) access to the global variables that are initialized at the top of the file!
    global controller_error, controller_error_previous, controller_error_integral, controller_error_derivative
    
    # Compute the error: difference between the target and the actual current state. 
    controller_error = target - actual
    
    # Compute the integral of the error. One-step Euler integration.
    controller_error_integral = controller_error_integral + dt*controller_error
    
    # Compute the derivative of the error. One-step finite difference approximation. 
    controller_error_derivative = (controller_error - controller_error_previous)/dt
    
    # We are done with the previous value of error... set that variable to the current error to remember it for next timestep. 
    controller_error_previous = controller_error
    
    # Actually compute the Motor command
    command = Kp*controller_error + Ki*controller_error_integral + Kd*controller_error_derivative
    return command

def pidControl1(target, actual, dt):
    """
    takes a target value and an actual value, and dt, and computes PID controller output
    """
# =============================================================================
#     # MANIPULATE these constants to tune controller
# =============================================================================
    #Kp = 20.
    #Ki = 8.
    #Kd = 0.2
    Kp = 50.
    Ki = 20.
    Kd = 0.2

    # We are using Global variables just so they stay in memory. 
    # Here the word "global" gives this function (pidControl) access to the global variables that are initialized at the top of the file!
    global controller_error1, controller_error_previous1, controller_error_integral1, controller_error_derivative1
    
    # Compute the error: difference between the target and the actual current state. 
    controller_error1 = target - actual
    
    # Compute the integral of the error. One-step Euler integration.
    controller_error_integral1 = controller_error_integral1 + dt*controller_error1
    
    # Compute the derivative of the error. One-step finite difference approximation. 
    controller_error_derivative1 = (controller_error1 - controller_error_previous1)/dt
    
    # We are done with the previous value of error... set that variable to the current error to remember it for next timestep. 
    controller_error_previous1 = controller_error1
    
    # Actually compute the Motor command
    command = Kp*controller_error1 + Ki*controller_error_integral1 + Kd*controller_error_derivative1
    return command



def pidAngleSpeedControl0(speed_target, speed_actual, current_pitch, dt):
    """
    takes a target value and an actual value, and dt, and computes PID controller output
    """
# =============================================================================
#     # MANIPULATE these constants to tune controller
# =============================================================================
    Kp_speed = 6.#15#1.5 # proportional gain for speed control (60) 1:15
    Ki_speed = .0 #1.5 # integral gain for speed control(30) 1:35
    Kd_speed = .05 #1.5 # integral gain for speed control(30) 1:35
    Kp_angle = 20.#10 # propotional gain for angle control
    Ki_angle = 5.#k_p_angle/6. # integral gain for angle control
    Kd_angle = 0.5 # derivatibe gain for angle control
    
    #speed_target = 0.1
    global angle_target
    angle_target = 0.0
    
    # We are using Global variables just so they stay in memory. 
    # Here the word "global" gives this function (pidControl) access to the global variables that are initialized at the top of the file!
    global speed_error0, speed_error_previous0, speed_error_integral0, speed_error_derivative0, angle_error0, angle_error_previous0, angle_error_integral0, angle_error_derivative0
    
    # Compute the error: difference between the target speed and the actual speed current state. 
    speed_error0 = speed_target - speed_actual
    # Compute the integral of the error. One-step Euler integration.
    speed_error_integral0 = speed_error_integral0 + dt*speed_error0
    # Compute the derivative of the error. One-step finite difference approximation. 
    speed_error_derivative0 = (speed_error0 - speed_error_previous0)/dt
    # We are done with the previous value of error... set that variable to the current error to remember it for next timestep. 
    speed_error_previous0 = speed_error0
    # Actually compute the Motor command
    angle_target = 1 * (Kp_speed*speed_error0 + Ki_speed*speed_error_integral0 + Kd_speed*speed_error_derivative0)
    print('taget angle: '+str(angle_target)+"\tcurrent angle: "+str(current_pitch))    
    if current_pitch <= 55 and current_pitch >= -55:
        # P
        angle_error0 = angle_target - current_pitch
        # I
        angle_error_integral0 = angle_error_integral0 + dt*angle_error0
        # D
        angle_error_derivative0 = (angle_error0 - angle_error_previous0)/dt
        # store previous
        angle_error_previous0 = angle_error0
            
        # Effort
        command = 1*(Kp_angle*angle_error0 + Ki_angle*angle_error_integral0 + Kd_angle*angle_error_derivative0)
        return command
        #record(time_current,speed_desired,current_wheel_speed,speed_error,speed_error_cum,angle_target,current_pitch,angle_error,angle_error_cum,angle_diff,motor_output)
    else:
        command = 0
        return command
        #run = False
        #file.close()
    
def pidAngleSpeedControl1(speed_target, speed_actual, current_pitch, dt):
    """
    takes a target value and an actual value, and dt, and computes PID controller output
    """
# =============================================================================
#     # MANIPULATE these constants to tune controller
# =============================================================================
    Kp_speed = 3.#15#1.5 # proportional gain for speed control (60) 1:15
    Ki_speed = .0#1.5 # integral gain for speed control(30) 1:35
    Kd_speed = .0 #1.5 # integral gain for speed control(30) 1:35
    Kp_angle = 20.#10 # propotional gain for angle control
    Ki_angle = 0.#k_p_angle/6. # integral gain for angle control
    Kd_angle = 0. # derivatibe gain for angle control
    
    #speed_target = 0.1
    global angle_target
    angle_target = 0.0
    
    # We are using Global variables just so they stay in memory. 
    # Here the word "global" gives this function (pidControl) access to the global variables that are initialized at the top of the file!
    global speed_error1, speed_error_previous1, speed_error_integral1, speed_error_derivative1, angle_error1, angle_error_previous1, angle_error_integral1, angle_error_derivative1
    
    # Compute the error: difference between the target speed and the actual speed current state. 
    speed_error1 = speed_target - speed_actual
    # Compute the integral of the error. One-step Euler integration.
    speed_error_integral1 = speed_error_integral1 + dt*speed_error1
    # Compute the derivative of the error. One-step finite difference approximation. 
    speed_error_derivative1 = (speed_error1 - speed_error_previous1)/dt
    # We are done with the previous value of error... set that variable to the current error to remember it for next timestep. 
    speed_error_previous1 = speed_error1
    # Actually compute the Motor command
    angle_target = 1 * (Kp_speed*speed_error1 + Ki_speed*speed_error_integral1 + Kd_speed*speed_error_derivative1)
    print('taget angle: '+str(angle_target)+"\tcurrent angle: "+str(current_pitch))    
    if current_pitch <= 55 and current_pitch >= -55:
        # P
        angle_error1 = angle_target - current_pitch
        # I
        angle_error_integral1 = angle_error_integral1 + dt*angle_error1
        # D
        angle_error_derivative1 = (angle_error1 - angle_error_previous1)/dt
        # store previous
        angle_error_previous1 = angle_error1
            
        # Effort
        command = 1*(Kp_angle*angle_error1 + Ki_angle*angle_error_integral1 + Kd_angle*angle_error_derivative1)
        return command
        #record(time_current,speed_desired,current_wheel_speed,speed_error,speed_error_cum,angle_target,current_pitch,angle_error,angle_error_cum,angle_diff,motor_output)
    else:
        command = 0
        return command
        #run = False
        #file.close()
    
def currentPitchAngle(mpu, dt):
    # Get the processed values from IMU
    mpu.processIMUvalues()

    # Acceleration vector angle
    accRoll = math.degrees(math.atan2(mpu.az, mpu.ay))
    accPitch = -math.degrees(math.atan2(mpu.az, mpu.ax))

    # Gyro integration angle
    mpu.gyroRoll += mpu.gx * dt
    mpu.gyroPitch -= mpu.gy * dt
    mpu.gyroYaw += mpu.gz * dt
    mpu.yaw = mpu.gyroYaw

    # Comp filter
    mpu.roll = (mpu.tau)*(mpu.roll + mpu.gx*dt) + (1-mpu.tau)*(accRoll)
    mpu.pitch = (mpu.tau)*(mpu.pitch - mpu.gy*dt) + (1-mpu.tau)*(accPitch)

    # Print data
    #print(" R: " + str(round(mpu.roll,1)) \
    #    + " P: " + str(round(mpu.pitch,1)) \
    #    + " Y: " + str(round(mpu.yaw,1)))
    
    #return pitch angle
    return round(mpu.pitch,1)
    

#--------------main-----------------
def main():
    
    # Set up class
    gyro = 250      # 250, 500, 1000, 2000 [deg/s]
    acc = 2         # 2, 4, 7, 16 [g]
    tau = 0.98
    mpu = MPU(gyro, acc, tau)

    # Set up sensor and calibrate gyro with N points
    mpu.setUp()
    mpu.calibrateGyro(500)
    print("MPU Calibration Complete")
    
# =============================================================================
#     Set up a time course of commands
# =============================================================================
    # duration of trajectory
    t_max = 5.
    # How often can you send a command ? 
    dt_traj = 0.01
    # Time array for the trajectory
    traj_time = np.linspace(0.,t_max,np.int(np.ceil(t_max/dt_traj)))
    n = len(traj_time)
    # Speed Commands array for the trajectory 
    traj_ang = np.linspace(0.,480.,n)
    
#    # Arrays to collect data. [Could also be used to set up pre-specified commands, e.g. by planning a sequence of "targets"]
#    time_array = np.zeros([n,2])    # "range" builds a row vector, so it has to be transposed to make a column vector.
#    target_array = np.zeros([n,2])  # Array to accumulate values the motor will be asked to hit. 
#    actual_array = np.zeros([n,2])  # Array to accumulate values the motor actually hits
#    control_voltage_array = np.zeros([n,2])     # Array of control voltages
#    theta_array = np.zeros([n,2])       # Array of motor angles
#    omega_array = np.zeros([n,2])       # Array of motor speeds

    
# =============================================================================
#    Below is a loop that's controlled by getting data from the serial port. 
#    That's where we get the state of each motor from the Encoders (all the "ser.____" stuff)
# =============================================================================

    # Initialize variables
    tstart = time.time()
    t0 = tstart
    t1 = tstart
    cnt0 = 0
    cnt1 = 0
    ang0 = 0
    ang1 = 0
    angvel0 = 0
    angvel1 = 0
    ind = 0     # Counter for logging data
    
    newdata = 0
    newE0 = 0
    newE1 = 0
    target_velocity = 8.0
    
    ## Clear the Serial Port so you don't have a big backlog of data 
    #ser.reset_input_buffer() 
    ser.flushInput()
    ser.readline()
    
    #IMU Results storage
    s_e0=[];s_e1=[]; s=[]; a=[]; b=[]; t =[]; imu_data=[]
#==============================================================================
#     Main Loop
#==============================================================================
    while time.time()-tstart < t_max:
        
        try:    # "try" runs code, but if there's a problem that throws an "exception"...
                # it will catch the exception without crashing the program
            # Here we read the serial port for a string that looks like "e0:123456", which is an Encoder0 reading. 
            # When we get a reading, update the associated motor command
            line = ser.readline().decode().strip() #ser.readline is a blocking function, will wait until reads entire line
            print(line)
            line = line.split(":")
            #print(line[0])
            if line[0] == 'E0':    #only use it as an encoder0 reading if it is one. 
                t0_old = t0
                ang0_old = ang0
                cnt0 = int(line[1])    # Here is the actual encoder reading. 
                t0 = time.time()
                ang0 = encoder_counts_to_output_shaft_radians(cnt0,1)    # you will use Motor and Gearbox Properties to determine the actual Angle. 
                angvel0 = calculate_angvel(ang0_old, ang0, t0-t0_old)
                #print([cnt0,cnt1, ang0,ang1, angvel0,angvel1])
                newdata = 1
                newE0 = 1
            elif line[0] == 'E1':    #only use it as an encoder1 reading if it is one. 
                t1_old = t1
                ang1_old = ang1
                cnt1 = int(line[1])    # Here is the actual encoder reading. 
                t1 = time.time()
                ang1 = encoder_counts_to_output_shaft_radians(cnt1,-1)    # you will use Motor and Gearbox Properties to determine the actual Angle. 
                angvel1 = calculate_angvel(ang1_old, ang1, t1-t1_old)
                #print([cnt0,cnt1, ang0,ang1, angvel0,angvel1])
                newdata = 1
                newE1 = 1 
        
        except: # "except" catches any exceptions that occur within the "try" block
            traceback.print_exc() # Print any error and its traceback stack
            pass    # "pass" doesn't do anything. But we need a line here so the syntax works. (thought the Traceback also fixes it)


        if newdata:
            
            pass
            
# =============================================================================
#     #Controlling the motor here by un-commenting different lines.
# =============================================================================           
        #controller functions 
        #note - only use one type of control at a time!
        #motor1_setting = pidControl(target_position, current_position)
        if newE0:
            newE0 = 0
            #target_velocity = 5.0
            current_velocity = angvel0
            current_pitch = currentPitchAngle(mpu, t0-t0_old)
            #target_position=20.0
            #motor1_setting = pidControl0(target_velocity, current_velocity, t0-t0_old)
            #motor1_setting = pidControl(target_position, ang0, t0-t0_old)
            motor1_setting = pidAngleSpeedControl0(target_velocity, current_velocity, current_pitch, t0-t0_old)
            motors.motor1.setSpeed(np.int(motor1_setting))
#            print([target_position, ang0, motor1_setting])
#            print([target_velocity, current_velocity,motor1_setting])
    
        if newE1:
            newE1 = 0
            #target_velocity = 5.0
            current_velocity = angvel1
            current_pitch = currentPitchAngle(mpu, t1-t1_old)
            #motor2_setting = pidControl1(target_velocity, current_velocity, t1-t1_old)
            motor2_setting = pidAngleSpeedControl1(target_velocity, current_velocity, current_pitch, t1-t1_old)
            motors.motor2.setSpeed(np.int(motor2_setting))
#             print([target_velocity, current_velocity,motor2_setting])

        newdata = 0

# =============================================================================
#     #Controlling the motor here by un-commenting different lines.
# =============================================================================           
        #controller functions 
        #note - only use one type of control at a time!
        #motor1_setting = pidControl(target_position, current_position)
        #motor1_setting = pidControl(target_velocity, current_velocity)
        #motor1_setting = pidControl0(target_velocity, current_velocity, t0-t0_old)
        #motor2_setting = pidControl0(target_velocity, current_velocity, t1-t1_old)
        
#        #drive motor
#        motor1_setting = traj_ang[traj_time<time.time()][-1]  # command for the first motor (index 0)
#        motor2_setting = traj_ang[traj_time<time.time()][-1]  # command for the second motor (index 1)
        #motors.motor1.setSpeed(np.int(motor1_setting))
        #motors.motor2.setSpeed(np.int(motor2_setting))
#        
# =============================================================================
#     #
# =============================================================================  

#        #backup history variables
#        #radPast = radians
#        time_array[ind,:] = [t0,t1]    # "range" builds a row vector, so it has to be transposed to make a column vector.
#        target_array = np.zeros([n,2])  # Array to accumulate values the motor will be asked to hit. 
#        actual_array = np.zeros([n,2])  # Array to accumulate values the motor actually hits
#        control_voltage_array = np.zeros([n,2])     # Array of control voltages
#        theta_array = np.zeros([n,2])       # Array of motor angles
#        omega_array = np.zeros([n,2])       # Array of motor speeds
#        
#        ind += 1

#        imu_data=read_imu()
#        print(imu_data)
#        x.append(imu_data[3])
#        y.append(imu_data[4])
        s_e0.append(angvel0)
        s_e1.append(angvel1)
        s.append(8)
        #x.append(imu_data[6])
        #y.append(imu_data[7])
#        x.append(angvel0)
#        y.append(angvel1)
        t.append(t0)
#        timeNow = int(time.time())
#        t.append(timeNow)
        a.append(angle_target)
        b.append(current_pitch)


    # when it gets here the trajectory is over. 
    motors.motor1.setSpeed(0)
    motors.motor2.setSpeed(0)
    
    #plot the graphs.
    g_encoder=1
    if g_encoder == 1:
        plt.subplot(2, 1, 1)
        plt.ylim(-25,20)
    #    plt.plot(t,x)
        plt.plot(t,s_e0,t,s,'r--')
    #    plt.plot(t,x,t,y)
        plt.xlabel('Time(s)')
        plt.ylabel('Velocity')
    #    plt.ylabel('X and Y Velocity Rotation(degrees)')
        plt.title('Encoder1_oscillations_velocity')
        plt.gca().legend(('current_velocity','target_velocity'))
        #plt.gca().legend(('x','y'))
    elif g_encoder==2:
        plt.subplot(2, 1, 1)
        plt.ylim(-25,10)
    #    plt.plot(t,x)
        plt.plot(t,s_e1,t,s,'r--')
    #    plt.plot(t,x,t,y)
        plt.xlabel('Time(s)')
        plt.ylabel('Velocity')
    #    plt.ylabel('X and Y Velocity Rotation(degrees)')
        plt.title('Encoder2_oscillations_velocity')
        plt.gca().legend(('current_velocity','target_velocity'))
        #plt.gca().legend(('x','y'))        
    plt.subplot(2, 1, 2)
    plt.plot(t,a,t,b)
    plt.xlabel('Time(s)')
    plt.ylabel('Pitch Rotation(degrees)')
    plt.title('imu_oscillations_pitchAngle')
    plt.gca().legend(('calc_angle_target','current_pitch'))
    plt.show()
    #plt.savefig('imu_oscillations.png')
    plt.close()



#if __name__=="__main__":
#    try:
#        main()
#
#    except:
#        print('Broke') 
        
main()